#!/bin/sh
./autogen.sh CFLAGS="-ggdb -O0 -Wall"
