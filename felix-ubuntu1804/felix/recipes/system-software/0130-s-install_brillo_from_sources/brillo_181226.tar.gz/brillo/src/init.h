#ifndef INIT_H
#define INIT_H

bool init_strings(light_conf_t *conf);
void light_free(light_conf_t *conf);

#endif /* INIT_H */
