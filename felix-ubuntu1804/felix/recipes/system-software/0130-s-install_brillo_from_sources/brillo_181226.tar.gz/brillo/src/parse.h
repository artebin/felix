#ifndef PARSE_H
#define PARSE_H

#include "light.h"

light_conf_t *parse_args(int argc, char **argv);

#endif /* PARSE_H */
