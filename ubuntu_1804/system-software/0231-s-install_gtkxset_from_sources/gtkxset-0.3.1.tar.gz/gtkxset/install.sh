#!/bin/sh
# install script for gtkxset

cd $(dirname $0)

# Create base dirs
install -d -m 755 $DESTDIR/usr/bin
install -d -m 755 $DESTDIR/usr/share/applications
install -d -m 755 $DESTDIR/usr/share/gtkxset

# Install icons
#for i in `ls icons/*.svg`; do
#	install -d -m 755 $DESTDIR/usr/share/icons/hicolor/scalable/apps/
#	install -m 644 $i $DESTDIR/usr/share/icons/hicolor/scalable/apps/
#done

#for i in 64 48 32 24 22 16; do
#	for j in `ls icons/*-$i.png 2> /dev/null`; do
#		install -d -m 755 \
#		$DESTDIR/usr/share/icons/hicolor/${i}x${i}/apps/ \
#		2> /dev/null
#		install -m 644 $j \
#		$DESTDIR/usr/share/icons/hicolor/${i}x${i}/apps/`basename $j|sed "s/-$i//"`
#	done
#done

# Install tools + lang files
install -m 755 src/gtkxset $DESTDIR/usr/bin/
install -m 644 src/gtkxset.desktop $DESTDIR/usr/share/applications/
install -d -m 755 $DESTDIR/usr/share/gtkxset/$i
install -m 644 src/gtkxset.glade $DESTDIR/usr/share/gtkxset/
for j in `ls src/po/*.mo`; do
	install -d -m 755 \
	$DESTDIR/usr/share/locale/`basename $j|sed "s/.mo//"`/LC_MESSAGES \
	2> /dev/null
	install -m 644 $j \
	$DESTDIR/usr/share/locale/`basename $j|sed "s/.mo//"`/LC_MESSAGES/gtkxset.mo
done
