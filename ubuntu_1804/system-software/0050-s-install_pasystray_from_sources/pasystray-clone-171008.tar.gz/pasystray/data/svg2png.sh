convert \
    -background none \
    -resize 48x48 \
    pasystray.svg \
    pasystray.png
